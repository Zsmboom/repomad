# LethalCompanyValuables
**Adds 30 scrap items from Lethal Company as valuables.**

## Valuables
- Airhorn
- Apparatus
- Big Bolt
- Bottles
- Brass Bell
- Cash Register
- Chemical Jug
- Clown Horn
- Fancy Lamp
- Flask
- Gift Box
- Gold Bar
- Golden Cup
- Hair Brush
- Hairdryer
- Jar Of Pickles
- Large Axle
- Painting
- Magnifying Glass
- Metal Sheet
- Old Phone
- Perfume Bottle
- Plastic Fish
- Red Soda
- Rubber Ducky
- Tea Kettle
- Teeth
- Toy Cube
- Toy Robot
- V-Type Engine

## Developer Contact
**Report bugs, suggest features, or provide feedback:**
- **Email:** crithaxxog@gmail.com
- **Twitch:** [CritHaxXoG](https://www.twitch.tv/crithaxxog)
- **YouTube:** [Zehs](https://www.youtube.com/channel/UCb4VEkc-_im0h8DKXlwmIAA)

[![kofi](https://i.imgur.com/jzwECeF.png)](https://ko-fi.com/zehsteam)