# LegoGnomes 
Changes the gnome's death sound to the lego brick breaking sound effect, which works really well with their death animation of splitting into many pieces!
<br />
