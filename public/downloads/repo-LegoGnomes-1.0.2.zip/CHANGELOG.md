# Changelog
## 1.0.2
Fixed rare naming conflict with asset bundle, and actually targets the right BepInEx version
## 1.0.1
Fixed BepInEx dependency version
## 1.0.0
Initial release!
