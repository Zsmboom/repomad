# Description
Health Packs now work for the whole team!

## Note
Ensure that everyone has the same `HealAmountMultiplier` value in their config. For now, I'm not sure how to override the value on the server.

## Feedback and Suggestions
If you have any feedback or suggestions, feel free to open an issue on the [GitHub repository](https://github.com/EvilCheetah/repo.mods).

## Say Thanks
If you'd like to show your appreciation, you can give me a profile award on my [Steam Page](https://steamcommunity.com/id/EvilCheetah/).
