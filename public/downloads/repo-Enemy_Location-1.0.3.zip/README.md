# Enemy Location

## Update History

### 1.0.1

Remove unrelated function which is discovering all valuableObject.
Add Config File

### 1.0.2
Fix: Enemy Location will be removed when enemy is despawned

### 1.0.3
Important Fix: Enemy Location will work now in multiplay when you are not host.