# Changelog

## [1.0.1] - 2025-03-04
### Fixed
- Fixed the config variable name `ExtraHealth` in the configuration file.

## [1.0.0] - 2025-03-01
### Added
- Initial release of the More Revive HP mod.
- Increase the health of players upon revival at extractor.
- Configuration option to set the amount of extra health added.
