Version 1.3.2 -> 1.3.3

- Switched font to REPO´s font (Teko)
- Made text bigger
- Fixed a few minor bugs